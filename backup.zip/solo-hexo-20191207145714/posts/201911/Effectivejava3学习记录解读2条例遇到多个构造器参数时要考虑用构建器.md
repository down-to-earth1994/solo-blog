title: Effective java (3) 学习记录解读 - 2条例： 遇到多个构造器参数时要考虑用构建器
date: '2019-11-05 14:55:01'
updated: '2019-11-05 14:55:22'
tags: [Effectivejava]
permalink: /articles/2019/11/05/1572936901510.html
---
![](https://img.hacpai.com/bing/20180507.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

```
/**  
 * 构建器模式  
 * Created by yulinfeng on 2017/8/3.  
 */  
public class Student {  
 /*必填*/  
 private String name;  
 private int age;  
 /*选填*/  
 private String sex;  
 private String grade;  
  
 public static class Builder {  
 private String name;  
 private int age;  
 private String sex = "";  
 private String grade = "";  
  
 public Builder(String name, int age) {  
 this.name = name;  
 this.age = age;  
 }  
 public Builder sex(String sex) {  
 this.sex = sex;  
 return this;  
 }  
 public Builder grade(String grade) {  
 this.grade = grade;  
 return this;  
 }  
 public Student build() {  
 return new Student(this);  
 }  
 }  
 private Student(Builder builder) {  
 this.name = builder.name;  
 this.age = builder.age;  
 this.sex = builder.sex;  
 this.grade = builder.grade;  
 }  
}
```

拥抱 lombok 去除烦人的get set build 代码自行百度
我们构造例子 就可以
```
Student student = new Student.Builder("kevin", 23).grade("1年级").build();
```

这样的客户端代码很容易边写，并且便于阅读。对于不了解的可能来说利用构建器模式编写Student类不算易事，甚至代码比重叠构造器的代码更多。所以当可选参数在很多时，谨慎使用重叠构造器，而是使用构建器模式。
