title: So we still don't know if he lived or died
date: '2019-11-25 22:06:25'
updated: '2019-11-25 22:06:25'
tags: [EnglishStudy]
permalink: /articles/2019/11/25/1574690785887.html
---
![](https://img.hacpai.com/bing/20190518.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
		**Yesterdat there was terrible accident.**
```

	It happend in front of a subway station.
	There was a crosswalk,and the light was red.
	Cars were coming from all directions.
	A yong man wanted to cross the street.
	He didn't want to wait for the light to change.
	he looked both ways and then started to  run across the street
	but he didn't see one car ,and it hit him
	he flew up into the air and come down on the road
	His head was injured and he was bleeding
	Serveral people  used their phones to call for an ambulance
	it arrived a few minutinus later and  took the man away
	we still don't know if he lived or died
	Hopefully he's alive and will get better soon
	so be careful when you cross a street


	昨天发生了一起可怕的事故。
	事情发生在地铁站前。
	那里有人行横道，而且是红灯。
	汽车从四面八方开来。
	一个年轻人想过马路。
	他不想等着光线改变。
	他朝两边看了看，然后开始跑过马路
	但是他没有看到一辆车，车撞了他
	他飞上了天空，落在路上
	他的头受伤了，还在流血
	有几个人用手机叫救护车
	几分钟后它来了，把那个人带走了
	我们仍然不知道他是死是活
	希望他还活着，早日康复
	所以过马路时要小心

