title: CSS 复习 --CSS 轮廓
date: '2019-11-12 10:40:07'
updated: '2019-11-12 10:40:07'
tags: [CSS]
permalink: /articles/2019/11/12/1573526407102.html
---
![](https://img.hacpai.com/bing/20180112.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 轮廓（outline）

1:在元素周围画线
`border:1px solid red; outline:green dotted thick;`
2 所有 CSS 轮廓（outline）属性

```
outline
	*outline-color  
	 outline-style  
	 outline-width  
	 inherit*
outline-color
	*color-name  
	 hex-number  
	 rgb-number  
	 invert
	 inherit*
outline-style 
	none  
	dotted  
	dashed  
	solid  
	double  
	groove  
	ridge  
	inset  
	outset  
	inherit
	
outline-width
	thin  
	medium  
	thick  
	length  
	inherit
```
