title: CSS  复习 -- 文本例子
date: '2019-11-04 15:17:43'
updated: '2019-11-05 14:49:46'
tags: [CSS]
permalink: /articles/2019/11/04/1572851863420.html
---
![](https://img.hacpai.com/bing/20180507.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

1:设置文本的颜色
	```
	 h1 {
	    color: #00ff00;
	  } 
	  p.ex {
	    color: rgb(0, 0, 255);
	  }
	```

2:设置文本的背景颜色
	```
	span.highlight  
	 {  
	 background-color:yellow  
	 }
	```

3:规定字符间距离
	```
	h1 {letter-spacing: -0.5em}
	h4 {letter-spacing: 20px}
	```
4:使用百分比设置 / 数字 /像素 行间距
	```
	p.small {line-height: 90%}
	p.big {line-height: 200%}
	p.small {line-height: 0.5}   
	p.big{line-height: 2}
	p.small { line-height: 10px }
	p.big { line-height: 30px}
	```

5: 对齐文本
	```
	h1 {text-align: center}  
	h2 {text-align: left}  
	h3 {text-align: right}
	```

6:修饰文本
	```
	h1 {text-decoration: overline} 
	h2 {text-decoration: line-through}
	h3 {text-decoration: underline}
	h4 {text-decoration:blink}
	a {text-decoration: none}
	```
	```
	    none:　默认值。无装饰
	    blink:　闪烁
	    underline:　下划线
	    line-through:　贯穿线
	    overline:　上划线 
	```

7:缩进文本
	 ```
	p {text-indent: 1cm}
	```

8:控制文本中的字母
	```
	 h1 {text-transform: uppercase}
	  p.uppercase {text-transform: uppercase}
	  p.lowercase {text-transform: lowercase}
	  p.capitalize {text-transform: capitalize}
	```

9:控制文本折行
	```
	p {  white-space: nowrap  }
	```

10:增加单词间距
	```
	p.spread {word-spacing: 30px;}
	p.tight {word-spacing: -0.5em;}
	```
