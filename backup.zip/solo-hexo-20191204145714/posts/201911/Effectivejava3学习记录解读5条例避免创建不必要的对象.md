title: Effective java (3) 学习记录解读  5条例 避免创建不必要的对象
date: '2019-11-06 16:53:27'
updated: '2019-11-06 16:55:07'
tags: [Effectivejava]
permalink: /articles/2019/11/06/1573030407016.html
---
**避免创建不必要的对象**

```
**当你应该重用现有对象的时候，请不要创建新的对象**
```

```
String str = “hello”;  
String str = new String(“hello”);
```

第一种 String 字符串的创建是在方法区（JDK7 后改到了堆内存）中的常量池中创建一个”hello”常量，将来若再有一个字符串变量为“hello”时将直接指向常量池中的“hello”变量而不用重新创建；第二种则是会在堆变量中创建一个新的 String 实例，将来若再以此方式创建一个字符串变量为“hello”时还是会重新创建一个 String 实例。显然第二种方式创建了一个“不必要”的实例，相比较而言第一种方式更加高效。

**书中举例子：是否是在 1946 年至 1964 年出生来说明**
每次都创建对象写法

```
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * “是否在1946-1965年出生”
 * 这在现实中应该是比较常见的一种写法
 * Created by  heyanfeng
 */
public class Person {
    private final Date birthDate;

    public Person(Date birthDate) {
        this.birthDate = birthDate;
    }

    public boolean isBabyBoomer() {
        Calendar gmtCal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));    //新创建Calendar实例
        gmtCal.set(1949, Calendar.JANUARY, 1, 0, 0, 0);
        Date boomStart = gmtCal.getTime();  //新创建Date实例
        gmtCal.set(1965, Calendar.JANUARY, 1, 0, 0, 0);
        Date boomEnd = gmtCal.getTime();    //新创建Date实例
        return birthDate.compareTo(boomStart) >= 0 && birthDate.compareTo(boomEnd) < 0;
    }
}
```

**高级写法**

```
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * “是否在1946-1965年出生”
 * 这在现实中应该是比较常见的一种写法
 * Created by heyanfeng
 */
public class Person {
    private final Date birthDate;
    private static final Date BOOM_START;
    private static final Date BOOM_END;
    static {
        Calendar gmtCal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));    //新创建Calendar实例
        gmtCal.set(1949, Calendar.JANUARY, 1, 0, 0, 0);
        BOOM_START = gmtCal.getTime();  //新创建Date实例
        gmtCal.set(1965, Calendar.JANUARY, 1, 0, 0, 0);
        BOOM_END = gmtCal.getTime();    //新创建Date实例
    }
    public Person(Date birthDate) {
        this.birthDate = birthDate;
    }

    public boolean isBabyBoomer() {
        return birthDate.compareTo(BOOM_START) >= 0 && birthDate.compareTo(BOOM_END) < 0;
    }
}
```

利用静态代码块在类 Person 初始化的时候创建对象，而在之后调用方法判断时不再每次重新创建新的实例对象，这种写法有点“烧脑”，确实有点“不符合”编码习惯，大概是因为这是需要思考才能写出来的原因吧。
