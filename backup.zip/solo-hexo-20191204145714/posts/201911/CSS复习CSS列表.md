title: CSS 复习 --CSS 列表
date: '2019-11-11 14:46:53'
updated: '2019-11-11 14:46:53'
tags: [CSS]
permalink: /articles/2019/11/11/1573454813327.html
---
# CSS 列表
1:## 不同的列表项标记
```
ul.a {list-style-type:circle;}
ul.b {list-style-type:square;}
ol.c {list-style-type:upper-roman;}
ol.d {list-style-type:lower-alpha;}
```
2## 作为列表项标记的图像
```
ul   
{  
 list-style-image:url('sqpurple.gif');  
}
```
3## 浏览器兼容性解决方案
```
ul  {  
	list-style-type:  none; 
	padding:  0px;
	margin:  0px;
 } 
 ul  li  {  
	background-image:  url(sqpurple.gif); 
	background-repeat:  no-repeat; 
	background-position:  0px  5px; padding-left:  14px; 
}
```
