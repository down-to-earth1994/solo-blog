title: Everyone needs food and water
date: '2019-11-26 21:25:44'
updated: '2019-11-26 21:25:44'
tags: [EnglishStudy]
permalink: /articles/2019/11/26/1574774744855.html
---
![](https://img.hacpai.com/bing/20191007.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

	Everyone needs food and water.
	Without food and water ,we cannot live.
	People need a place to live in and sleep.
	We need a place to keep us dry in rainy weather.
	We need good health to keep us strong.
	Daily exercise is a good way  to stay in good health.
	We need skills to find good job.
	Without good job skills ,we can't keep a good job.
	We need money to buy things ,such as food.
	Without money,It's very difficult to have a good life.
	Without water,our body dosen't work at all.
	Rich people have a lot of money.



	每个人都需要食物和水。
	没有食物和水，我们就不能生存。
	人们需要一个地方居住和睡觉。
	我们需要一个地方在雨天保持干燥。
	我们需要良好的健康来保持我们强壮。
	每天锻炼是保持健康的好方法。
	我们需要技能才能找到好工作。
	没有良好的工作技能，我们就不能保住一份好工作。
	我们需要钱来买东西，比如食物。
	没有钱，很难有一个好的生活。
	没有水，我们的身体就不能工作。
	富人有很多钱。

