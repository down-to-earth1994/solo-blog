title: State of water
date: '2019-11-26 21:57:52'
updated: '2019-11-26 21:57:52'
tags: [EnglishStudy]
permalink: /articles/2019/11/26/1574776672304.html
---
![](https://img.hacpai.com/bing/20191007.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

Ice is the soild state of water
The freezing point of water is 0 degrees Celsius.
This is the liquid state of water.
Liquids take the shape of their container such as this glass.
Water vapor is the  gaseous state of water.
Water becomes a gas at 100 degress Celsius ,which is its boiling point.
We use a scale like this to weigh things
One kilogram is equal to 2.2 pounds
This is a thermometer.
We use thermometers like this to measure temperature

冰是水的固体状态

水的凝固点是0摄氏度。

这是水的液态。

液体以容器的形状出现，比如这个玻璃杯。

水蒸气是水的气态。

水在摄氏100度时变成气体，摄氏100度是水的沸点。

我们用这样的秤来称东西

1千克等于2。2磅

这是温度计。

我们使用像这样的温度计来测量温度
