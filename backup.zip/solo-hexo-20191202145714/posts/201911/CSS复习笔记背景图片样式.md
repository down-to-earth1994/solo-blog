title: CSS 复习笔记 背景图片 样式
date: '2019-11-04 14:46:26'
updated: '2019-11-04 15:01:45'
tags: [CSS]
permalink: /articles/2019/11/04/1572849986496.html
---
![](https://img.hacpai.com/bing/20180612.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**一行搞定背景图片样式**
```
body {
  background: url("../../assets/logo.png");
  /* background-repeat: repeat-y; */
  /* background-repeat: repeat-x; */
  /* background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center;
  background-position: 30% 20%;
  background-position: 50px 100px; */
  background: #ff0000 url("../../assets/logo.png") no-repeat fixed center;
}
```
```
background-repeat-------背景图是否平铺  
	 no-repeat 不平铺
	 repeat-x 水平平铺
         repeat-y 垂直平铺

background-attachment-------背景图像是否固定或者随着页面的其余部分滚动
        scroll：默认值。背景图像会随着页面其余部分的滚动而移动。
  	fixed:当页面的其余部分滚动时，背景图像不会移动。
  	inherit:规定应该从父元素继承 background-attachment 属性的设置。

 background-position 定位 可以通过px 或者 % 来定位
 background-position: 30% 20%;
 background-position: 50px 100px; 
``` 



