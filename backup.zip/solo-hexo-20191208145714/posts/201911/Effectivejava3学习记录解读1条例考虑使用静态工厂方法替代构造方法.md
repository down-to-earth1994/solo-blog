title: Effective java (3) 学习记录解读 -   1条例： 考虑使用静态工厂方法替代构造方法
date: '2019-11-04 10:36:24'
updated: '2019-11-04 11:22:44'
tags: [EffectiveJava]
permalink: /articles/2019/11/04/1572834984322.html
---
![](https://img.hacpai.com/bing/20190625.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 1. 考虑使用静态工厂方法替代构造方法

  	就是除了平常使用的new 方法 构造出对象实例之外；还可以使用公共的静态方法 比如：
 	```
		public static Boolean valueOf(boolean b) {  
		return b ? Boolean.TRUE : Boolean.FALSE;  
		}
	```
      **使用静态工厂的五个优点：**
	 	1: **静态工厂方法的一个优点是，与构造方法不同，它们是有名字的**
		优点就是可以做到见名思意;  
		例如，返回一个可能为素数的 `BigInteger`的构造方法 `BigInteger(int，int，Random)` 可以更好地表示为名为 `BigInteger.probablePrime` 的静态工厂方法。

		2:**静态工厂方法的第二个优点是，与构造方法不同，它们不需要每次调用时都创建一个新对象。**
		优点：使用预先构建的实例，或者在构造时缓存实例，并反复分配它们以避免创建不必要的重复对象。对于经常请求等价对象，那么它可以极大地提高性能
		例如：```Boolean.valueof(boolean)``` ； 类比下单例的实现

		3:**静态工厂方法的第三个优点是，与构造方法不同，它们可以返回其返回类型的任何子类型的对象**
		优点：理解java 多态的含义；父类的引用指向子类的对象 	
		例如：面向接口编程 
       
		4:**静态工厂的第四个优点是返回对象的类可以根据输入参数的不同而不同**
		优点：java 重载的使用

		5:**在编写包含该方法的类时，返回的对象的类不需要存在**
		说明：本人理解起来有点费劲💧💧
		优点：更好的解耦代码  service provider frameworks （服务提供者框架）
		例如：[JDBC(Java数据库连接，Java Database Connectivity）
		```
		1 Class.forName(driverClass);
		2 //加载MySql驱动
		3 Class.forName("com.mysql.jdbc.Driver");
		4 //加载Oracle驱动
		5 Class.forName("oracle.jdbc.driver.OracleDriver");
		```
		获得数据库连接：
		```
 		DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/fireway", "root", "root");
		```
		创建Statement/PreparedStatement对象：
		```
		conn.createStatement();
		conn.prepareStatement(sql);
		```
		1. Connection就是JDBC的服务接口;
		2. `Class.forName("...")`会实例化一个com.mysql.jdbc.Driver类（服务提供者接口的实现类），并将这个类的实例注册到DriverManager.registerDriver（提供者注册API）;
		3. 通过建立连接的URL，用户名，密码来获取链接到mysql数据库的Connection服务。DriverManager.getConnection()是服务访问API, 返回的是具体的实现类对象。
		4. Driver就是服务提供者接口。

		通过上面的例子可以看出，我们只需要输入一个key就可以得到对应的类的实例，进而使用该类的方法，这种方法能大大降低代码的耦合度，这里的Map集合可以理解为服务提供者框架的注册机制，Map中的Key和Value的值都应该在配置的属性文件（properties）中，这样方便我们查看和添加服务类，我们只需要操作这个配置文件就可以了，这样我们的实际模式实现了java的解耦合问题

         

	

