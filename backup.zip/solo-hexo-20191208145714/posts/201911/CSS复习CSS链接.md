title: CSS 复习 --CSS 链接
date: '2019-11-11 14:39:41'
updated: '2019-11-11 14:39:41'
tags: [CSS]
permalink: /articles/2019/11/11/1573454381515.html
---
## CSS 链接

1:## 链接样式
a:link  {color:#000000;}  /* 未访问链接*/
a:visited  {color:#00FF00;}  /* 已访问链接 */
a:hover  		{color:#FF00FF;}  /* 鼠标移动到链接上 */
a:active  {color:#0000FF;}  /* 鼠标点击时 */

**注意：** a:hover 必须在 a:link 和 a:visited 之后，需要严格按顺序才能看到效果。

**注意：** a:active 必须在 a:hover 之后。

2:## 常见的链接样式

a:link  {text-decoration:none;}  
a:visited  {text-decoration:none;}  
a:hover  {text-decoration:underline;}  
a:active  {text-decoration:underline;}

text-decoration

3:## 背景颜色
a:link  {background-color:#B2FF99;}  
a:visited  {background-color:#FFFF85;}  
a:hover  {background-color:#FF704D;} 
a:active  {background-color:#FF704D;}
```
