title: CSS 复习 font 字体
date: '2019-11-06 09:56:08'
updated: '2019-11-06 09:56:20'
tags: [CSS]
permalink: /articles/2019/11/06/1573005368138.html
---
1: 设置字体

```
p.serif {
font-family: &quot;Times New Roman&quot;, Georgia, Serif;
}
p.sansserif {
font-family: Arial, Verdana, Sans-serif;
}

```

2:设置字体的尺寸

```
p.serif {
  font-family: "Times New Roman", Georgia, Serif;
}
p.sansserif {
  font-family: Arial, Verdana, Sans-serif;
}
```

3:设置字体的风格

```
p.normal {font-style:normal}  
p.italic {font-style:italic}  
p.oblique {font-style:oblique}
```

normal:无样式
italic：斜体。对于没有斜体变量的特殊字体，将应用
oblique:倾斜的字体

4:设置字体的异体

```
p.normal {font-variant: normal}  
p.small {font-variant: small-caps}
```

font-variant
属性设置小型大写字母的字体显示文本，这意味着所有的小写字母均会被转换为大写，但是所有使用小型大写字体的字母与其余文本相比，其字体尺寸更小

normal ： 默认值。浏览器会显示一个标准的字体
small-caps：浏览器会显示小型大写字母的字体
inherit ： 规定应该从父元素继承 font-variant 属性的值。

5:设置字体的粗细
```
p.normal {font-weight: normal}
p.thick {font-weight: bold}
p.thicker {font-weight: 900}
```

