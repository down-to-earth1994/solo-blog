title: Daily Readers
date: '2019-12-07 12:04:57'
updated: '2019-12-07 12:04:57'
tags: [EnglishStudy]
permalink: /articles/2019/12/07/1575691497905.html
---
What’s wrong with her.
He gave her a shot  in her arm.
Her mother gave Lisa’s name to the receptionist.
If she can’t be here ,we can set up a conference all.
He wanted to lie down.
He was just lying there.
which bus goes to neither the train station  nor the airport.
She’s   going to practic the piano   in   about ten minutes.
It’s going to take her 10 minutes.
Can you help me with homework question.
He woke up at 6.30
Her mother told her to stay in bed.
How was the yong man when the ambulance arrived.
She listened to some music.
The soft drinks have too  
They ate finishing  at 7.30
He listened to her heeartbeat.

The last bus came a few minutes ago.
Oh look! The NO.60   is coming  right   on schedule .
He had a bottle of water from home, so  he didn’t buy any something to drink.
It didn’t have  any taste at all.
By 6.00 she was feeling  some better.
She’s  looking forward to going to  school.
This is what Lisa is going to do for the rest of the day.
Next week ,there will be  a piano competition.
Cars where come from all directions.
She slept for  a couple of hours .



她怎么了?
他在她手臂上打了一针。
她妈妈把丽莎的名字告诉了接待员。
如果她来不了，我们可以一起开会。
他想躺下。
他只是躺在那里。
哪辆公共汽车既不去火车站也不去机场。
她大约十分钟后要练钢琴。
她要花10分钟。
你能帮我做作业吗?
他6点半醒来
她妈妈叫她卧床休息。
当救护车到达时，那个年轻人怎么样了?
她听了一些音乐。
软饮料也有
他们吃到七点半
他听着她的心跳。

末班车几分钟前就来了。
哦,看!60路车正准时来。
他家里有一瓶水，所以他没有买任何喝的东西。
它一点味道都没有。
6点时她感觉好些了。
她盼望着去上学。
这就是丽莎今天接下来要做的事。
下周将有一场钢琴比赛。
汽车来自四面八方。
她睡了几个小时。
