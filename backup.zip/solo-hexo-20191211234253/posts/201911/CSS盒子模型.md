title: CSS 盒子模型
date: '2019-11-11 15:00:07'
updated: '2019-11-11 15:00:07'
tags: [CSS]
permalink: /articles/2019/11/11/1573455606961.html
---
# CSS 盒子模型
![CSS box-model](https://www.runoob.com/images/box-model.gif)
不同部分的说明：

* **Margin(外边距)** - 清除边框外的区域，外边距是透明的。
* **Border(边框)** - 围绕在内边距和内容外的边框。
* **Padding(内边距)** - 清除内容周围的区域，内边距是透明的。
* **Content(内容)** - 盒子的内容，显示文本和图像。

## 元素的宽度和高度
**重要:** 当您指定一个CSS元素的宽度和高度属性时，你只是设置内容区域的宽度和高度。要知道，完全大小的元素，你还必须添加填充，边框和边距。.

下面的例子中的元素的总宽度为300px：
```
div  {  width:  300px; border:  25px  solid  green; padding:  25px; margin:  25px; }
```
让我们自己算算：  
300px (宽)  
+ 50px (左 + 右填充)  
+ 50px (左 + 右边框)  
+ 50px (左 + 右边距)  
= 450px
