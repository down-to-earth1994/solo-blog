title: CSS 复习--表格
date: '2019-11-11 14:57:12'
updated: '2019-11-11 14:57:12'
tags: [CSS]
permalink: /articles/2019/11/11/1573455432315.html
---
![](https://img.hacpai.com/bing/20180925.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# CSS 表格

1## 表格边框
`table, th, td  {  border:  1px  solid  black; }`
2## 折叠边框
`table  {  border-collapse:collapse; }  table,th, td  {  border:  1px  solid  black; }`
3## 表格宽度和高度
`table { width:100%; } th { height:50px; }`
4### 表格文字对齐
`td  {  text-align:right; };td { height:50px; vertical-align:bottom; }`
5## 表格填充
'td  {  padding:15px; }'
6## 表格颜色
`table, td, th  {  border:1px  solid  green; }  th  {  background-color:green; color:white; }`
