title: CSS  复习 边框(border)
date: '2019-11-06 10:15:25'
updated: '2019-11-11 14:33:11'
tags: [CSS]
permalink: /articles/2019/11/06/1573006525432.html
---
![](https://img.hacpai.com/bing/20180221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

1:CSS 边框
```
每个边框有 3 个方面：宽度、样式，以及颜色
```

2:border-style 属性定义了 10 个不同的非 inherit 样式 包括 none

```
border-style 样式:
```

```
dotted 点状 
solid    实线
double  双线
dashed 虚线
```
扩展 10余种样式

	```
	none : 定义无边框  
 	hidden 与none 相同。不过应用表时除外，对于表hidden 用于解决边框冲突  
 	dotted 定义点状边框
	dashed 定义虚线。在大多数浏览器中呈现为实线
	solid 定义实线
	double 定义双线
	groove 定义3D 凹槽边框
	ridge 定义3D 垄状边框
	inset 定义 3D inset 边框
	outset 定义 3D outset 边框
	inherit 规定应该从父元素继承边框样式。
	```
3:边框宽度 && 边框颜色 
```
border-width:5px; 边框的宽度
border-color:red;
```
4:边框的单独设置各边
```
border-top-style:dotted; 
border-right-style:solid; 
border-bottom-style:dotted;
border-left-style:solid;
```
**口诀：**
```
border-style：属性1，属性2，属性3，属性4  
  
上->右->下->左  
  
border-style：属性1，属性2，属性3  
  
上->左右->下  
  
border-style：属性1，属性2  
  
上下->左右  
  
border-style：属性1  
  
上下左右属性相同
```


## CSS3 边框

border-radius
eg:
```
	div
	
	{
	
	 border:2px solid #a1a1a1;
	
	 padding:10px 40px; 
	
	 background:#dddddd;
	
	 width:300px;
	
	 border-radius:25px;
	
	}
```

## CSS3 盒阴影
box-shadow
	```
	box-shadow: 10px 10px 5px #888888;
	```


## CSS3 边界图片
**注意: **Internet Explorer 不支持 border-image 属性
border-image 属性用于设置图片的边框

	```
		border-image:url(border.png) 30 30 round;   
		-webkit-border-image:url(border.png) 30 30 round; /* Safari 5 and older */   
		-o-border-image:url(border.png) 30 30 round; /* Opera */
	```
