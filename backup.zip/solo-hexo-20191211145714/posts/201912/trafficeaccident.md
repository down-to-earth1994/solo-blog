title: traffice accident
date: '2019-12-02 21:19:35'
updated: '2019-12-02 21:21:19'
tags: [EnglishStudy]
permalink: /articles/2019/12/02/1575292775721.html
---
He ran out into the traffic and a car hit him.
It was going too fast to stop.
It took about 10 minutes
they called for ambulance.
he was just lying there.
He didn't want to wait for the light to change.
The police asked a lot of questions
The police were taking him .
I don't know .beacuse I had to get  home.
They came just before ambulance arrived.
when the ambulance left, he was siting in his car.
I think it took only ten minutes.
I kept think about it.
Ambulance carry sick or injured people to a hostpital
Don't cause an  accident and kill somebody.
He's dead because he was hit by a a car 
we need water to keep our bodies working.
The freezing point  of water is 0
Ice is the solid state of water.
She took some medicine and drank a lot of liquids
we use thermometers like this to measure temperature.


他跑进了车流中，一辆车撞了他。
车开得太快了，停不下来。
花了大约10分钟
他们叫了救护车。
他只是躺在那里。
他不想等着光线改变。
警察问了很多问题
警察把他带走了。
我不知道，因为我必须回家。
就在救护车到达之前，他们来了。
救护车离开时，他坐在车里。
我想只花了十分钟。
我一直在想。
救护车把生病或受伤的人送到医院
不要制造事故，也不要杀人。
他被车撞死了
我们需要水来维持我们的身体运转。
水的凝固点是0
冰是水的固态。
她吃了一些药，喝了很多水
我们使用像这样的温度计来测量温度。
