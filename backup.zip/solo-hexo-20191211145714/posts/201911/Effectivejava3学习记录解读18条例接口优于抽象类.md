title: Effective java (3) 学习记录解读 18条例 接口优于抽象类
date: '2019-11-06 16:54:18'
updated: '2019-11-06 18:07:38'
tags: [Effectivejava]
permalink: /articles/2019/11/06/1573030458374.html
---
## 接口优于抽象类	
	**接口不能被实例化不能有构造器****，****抽象类也不能被实例化但可以有构造器****；**

	**接口中不能有****实现****方法****（JDK****8在接口中****可以有实现方法，称“默认方法”），抽象类中可以有实现方法，也可以没有；**

	**接口方法的默认修饰符就是public****，****不可以用其他修饰符****，****抽象类可以有****public、protected、default。**
原因就是Java只支持单继承，但可以实现多个接口。有抽象类的地方基本上都可以看到其中的方法很多是模板方法

**模版方法模式讲解**
准备一个抽象类，将核心方法设计为模板方法，在抽象类中具体实现，然后声明一些抽象方法来迫使子类实现。不同的子类可以以不同的方式实现这些抽象方法，从而对剩余的逻辑有不同的实现。
抽象类（Animal）：定义了模板方法。

具体类（Human,Dog,Bird）:实现抽象类的方法。

模板类（Animal）：
```
package pattern;
public abstract class Animal {
 
 
	public Animal(){
	}
	public static final int SPEAK=1;
	public static final int SLEEP=3;
	public static final int MOVE=7;
	//抽象方法
	public abstract void speak();
	public abstract void sleep();
	public abstract void move();
	
	public void action(int num){
		switch(num){
		case SPEAK:
			this.speak();
			break;
		case SLEEP:
			this.sleep();
			break;
		case MOVE:
			this.move();
			break;
		default:
			break;
		}
	}
}

```
人类：
```
package pattern;
 
 
public class Human extends Animal{
 
 
	public Human(){
		System.out.println("人类登场：");
	}
   public void speak(){
	   System.out.println("你好啊！");
	}
	public void sleep(){
		System.out.println("我睡在床上。");
	}
	public void move(){
		System.out.println("坐公交");
	}
 
}
```
狗类:
```
package pattern;
 
 
public class Dog extends Animal{
 
 
	public Dog(){
		System.out.println("dog登场：");
	}
    public void speak(){
		System.out.println("汪汪汪!");
	}
	public void sleep(){
		System.out.println("小狗睡在地上。");
	}
	public void move(){
		System.out.println("奔跑");
	}
	
 
}
```
鸟类:
```
package pattern;
 
 
public class Bird extends Animal {
 
 
    public Bird(){
    	System.out.println("小鸟登场：");
    }
    public void speak(){
    	System.out.println("叽叽喳喳");
	}
	public void sleep(){
		System.out.println("小鸟睡在树上。");
	}
	public void move(){
		System.out.println("飞翔");
	}
 
}

```
```

package pattern;
 
public class MainClass {
	
	public static void main(String args[]){
		MainClass.action(new Human());
		MainClass.action(new Dog());
		MainClass.action(new Bird());
	}
	public static void action(Animal animal){
		animal.action(animal.SPEAK);
		animal.action(animal.SLEEP);
		animal.action(animal.MOVE);	
	}
}

```
	运行结果
	人类登场：  
	你好啊！  
	我睡在床上。  
	坐公交  
	dog登场：  
	汪汪汪!  
	小狗睡在地上。  
	奔跑  
	小鸟登场：  
	叽叽喳喳  
	小鸟谁在树上。  
	飞翔
