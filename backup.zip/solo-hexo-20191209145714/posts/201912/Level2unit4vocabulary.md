title: Level 2 unit 4 vocabulary
date: '2019-12-07 12:29:40'
updated: '2019-12-07 12:29:40'
tags: [EnglishStudy]
permalink: /articles/2019/12/07/1575692980389.html
---
as soon as possible
We’d like to see the doctor as soon as possible.
bottom
The girl on the bottom left is short; 
The bottom line is the shortest;
be ready for
to be fully prepared  for something that you are going to do.
Are you ready for  your history test?
change 
the act  or result  of something becoming different.
In nature ,even small changes can something have large effects.
It was a nice change.
classical

of or relating to a style of music written in Europe between the late 18th and early 19th centuries,classical music
They are many types of music, including classical and jazz. 

conversation
an informal talk involving two or more people.
we can listen to the news,music and conversation on the radio.
count 
to say number one after another in order.
decide
to make a choice about what you are going to do 
They decided to meet at a shopping mall.
She decided not to work out.


尽快
我们想尽快去看医生。
底
左下角的女孩很矮;
底线是最短的;
做好准备
对将要做的事情做好充分的准备。
你准备好考历史了吗?
改变
某事物变得不同的行为或结果。
在自然界中，即使是很小的变化也会产生很大的影响。
这是一个很好的改变。
经典

古典音乐的属于或关于18世纪末至19世纪初欧洲创作的一种音乐风格的古典音乐的
它们是很多种音乐，包括古典音乐和爵士乐。

谈话
有两个或两个以上的人参加的非正式谈话。
我们可以听收音机里的新闻、音乐和谈话。
数
按顺序一个接一个地说。
决定
选择你要做什么
他们决定在购物中心见面。
她决定不去健身。


