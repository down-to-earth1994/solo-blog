title: Effective java (3) 学习记录解读 25-28条例   列表优先于数组 && 优先考虑泛型 && 优先考虑泛型方法&& 利用有限制通配符来提升API的灵活性
date: '2019-11-07 14:37:51'
updated: '2019-11-07 14:38:09'
tags: [Effectivejava]
permalink: /articles/2019/11/07/1573108671603.html
---
![](https://img.hacpai.com/bing/20190906.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 列表优先于数组

数组是协变的：	
首先数组是协变的，这里的“变”指的是数据类型，而不是说数组的长度，数组的长度当然从一开始就确定不可改变，但对于以下代码确实合法的

```
public class Main {   
public static void main(String[] args) throws Exception{ 
	Object[] objects = new Long[1]; objects[0] = "hello world"; 
	System.out.println(objects[0]);
 }
 }
```
以上这个代码会在运行时期发生
![null](https://images2017.cnblogs.com/blog/630246/201708/630246-20170817225002443-1010344475.png)

在举例：
![null](https://images2017.cnblogs.com/blog/630246/201708/630246-20170817225025115-870300914.png)
这段代码在编译期就会报错。综上，利用数组只有在运行时才会报错，利用列表在编译时就会报错，我们当然希望在错误能在编译时尽早发现。

```
List<String>[] lists = new ArrayList<String>[1];    //先假设能创建泛型数组
List<Integer> intList = Arrays.asList(42);  //Integer列表
Object[] objects  = lists;  //根据数组的“协变性”是合法的，例如上面提到的Object[] objects = new Long[1]
objects[0] = intList;   //List<String>和List<Integer>在运行时类型会被擦除为List
String s = lists[0].get(0); //上一步操作过后，实际上取出的是一个initList，即取出是一个Integer
```
假设第一步不会报错，那么上面的例子在编译时就不会出错，但一到了运行时最后一句话就会抛出ClassCastException异常，也就是说与其在运行时出错，不如将它提前到编译时即不允许创建泛型数组。这就是为什么创建泛型数组是非法的原因****：因为它不是类型安全的。要是它合法，编译器在其他正确的程序中发生的转换就会在运行时失败，并出现一个ClassCast****Excetion****异常。这就违背了泛型系统提供的基本保证。

 ## 优先考虑泛型
```
List<?>[] lists = new ArrayList<?>[1];
```
泛型在运行时它的类型会被擦除，也就是说泛型是不可具体化的，它在运行时所包含的信息比它在编译时所包含的信息更少。唯一可具体化的参数化类型就是无限制的通配符类型，也就是上面提到的例子如List<?>。

此条目几乎一直在说数组和泛型不能很好的配合使用，如果遇到泛型的情况，应该首先考虑列表。

```
public static <T> void sort(List<T> list, Comparator<? super T> c)
```

## 利用有限制通配符来提升API的灵活性

之前我们提到了<?>形式的无限制通配符，这里则是有限制通配符。上一条目中已经出现了有限制通配符，它一共有这么2种：

　　**<? extends E>**：表示可接受E类型的子类型；

　　**<? super E>**：表示可接受E类型的父类型。
