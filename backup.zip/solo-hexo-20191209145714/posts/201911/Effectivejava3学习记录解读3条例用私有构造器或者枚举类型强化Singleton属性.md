title: Effective java (3) 学习记录解读 - 3条例 用私有构造器或者枚举类型强化Singleton属性
date: '2019-11-05 15:24:35'
updated: '2019-11-05 15:24:35'
tags: [Effectivejava]
permalink: /articles/2019/11/05/1572938675417.html
---
## 用私有构造器或者枚举类型强化 Singleton 属性

首先分析程序员人人都会写的（饿汉式）单例模式：

```
public class Instance {
	private static final Instance obj = new Instance();
	    private Instance() {}
	    public static Instance getInstance() {
	        return obj;
	    }
	}
```

此单例子是线程安全的，但是如果我们要求实现序列化，这个单例就不符合要求

**测试代码**

```
import java.io.Serializable;

/**
 * 序列化单例对象
 * Created by 贺艳峰.
 */
public class Instance implements Serializable {
    private static final Instance obj = new Instance();
    private Instance() {
        
    }
    public static Instance getInstance() {
        return obj;
    }
}
```

```
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * 序列化与反序列化单例对象
 * Created by  贺艳峰
 */
public class Main {
    public static void main(String[] args) throws Exception{
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("D:\\objFile.obj"));
        Instance instance = Instance.getInstance();
        out.writeObject(instance);
        out.close();
    
        ObjectInputStream in = new ObjectInputStream(new FileInputStream("D:\\objFile.obj"));
        Instance instance1 = (Instance) in.readObject();
        in = new ObjectInputStream(new FileInputStream("D:\\objFile.obj"));
        Instance instance2 = (Instance) in.readObject();
        System.out.println("obj1 hashcode:" + instance1.hashCode());
        System.out.println("obj2 hashcode:" + instance2.hashCode());
        in.close();
    }
}
```

比较两个实例对象的 hash 值，可以看到执行结果为：
([https://images2017.cnblogs.com/blog/630246/201708/630246-20170804222948803-1234340556.png](https://images2017.cnblogs.com/blog/630246/201708/630246-20170804222948803-1234340556.png))

**一探究竟 Java 序列化(细细品) 不想懂原理的可以放过**

1:序列化 (Serialization)是将对象的状态信息转换为可以存储或传输的格式的过程。 反序列化 (Deserialization)是通过从存储或者网络读取对象的状态，重新创建该对象。序列化广泛应用在远程调用（RPC）或者数据存取。

2:Java 为我们提供了 Serializable 接口，这是一个空接口；如果一个类实现了 Serializable 接口，那么就代表这个类是自动支持序列化和反序列化的，毋须我们编程实现。如果一个类没有实现 Serializable 接口，那么默认是不能被序列化的，除非使用其他办法。

3:Java 的 Serializable，只能序列化类的状态，不能序列化类的方法

4:如果一个类实现了 Serializable 接口，其父类没有实现 Serializable 接口，那么父类必须有无参的构造器，并且父类中的状态默认不能被序列化。如果想要序列化和反序列化父类，需要在子类里干预序列化的过程，例如使用 readObject 和 writeOjbect 方法来序列化和反序列化父类的状态
5: transient
我们不想序列化写到磁盘上，那么我们可以用 transient 关键字来标记它。
6:可以通过 readObject 和 writeOjbect 方法来干预序列化，例如把待序列化的对象的某个属性字段加密和解密，或者把 transient 关键字标记的属性序列化写出去。
7:Java 的序列化机制提供了一个钩子方法，即私有的 readresolve 方法，允许我们来控制反序列化时得到的对象。下面的代码就说明了 readresolve 方法的用法，可以看出反序列化得到的对象，还是唯一的单例对象。
与 readresolve 方法对应，还有一个 writeReplace 方法，可以让我们在 writeOjbect 方法之前修改序列化的对象。

```
1.ObjectOutputStream.writeObject(Object obj)
2.ObjectOutputStream.writeObject0(Object obj, boolean unshared)
3.ObjectOutputStream.writeOrdinaryObject(Object obj,
                                 ObjectStreamClass desc,
                                 boolean unshared)
// 就是在第4个方法里初始化了序列化回调上下文SerialCallbackContext
4.ObjectOutputStream.writeSerialData(Object obj, ObjectStreamClass desc)
5.ObjectStreamClass.invokeWriteObject(Object obj, ObjectOutputStream out)
// 6：通过反射调用Person类中的writeObject(ObjectOutputStream out)方法。
6.Method.invoke(Object obj, Object... args)
```

**这就说明被反序列化过后便不再是单例。要保证单例还必须在单例类中实现 readResolve 的方法：**

```
import java.io.Serializable;

/**
 * 序列化单例对象
 * Created by 贺艳峰
 */
public class Instance implements Serializable {
    private static final Instance obj = new Instance();
    private Instance() {
        
    }
    public static Instance getInstance() {
        return obj;
    }
    private Object readResolve(){
        return obj;
    }
}
```

**通过枚举方式的单例（可以防止序列化）**

```
/**
 * 枚举类型单例
 * Created by 贺艳峰
 */
public enum Instance {
    INSTANCE    //同样可以像普通类一样定义普通的方法变量等
}
```
